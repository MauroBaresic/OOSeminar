﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model.Repozitoriji
{
    /// <summary>
    /// Klasa koja predstavlja repozitorij za serije.
    /// </summary>
    public class SerijaRepozitorij
    {
        /// <summary>
        /// Singleton.
        /// </summary>
        private static SerijaRepozitorij _instanca = null;

        /// <summary>
        /// Vraća singleton.
        /// </summary>
        /// <returns>singleton</returns>
        public static SerijaRepozitorij dohvatiInstancu()
        {
            if (_instanca == null)
            {
                _instanca = new SerijaRepozitorij();
            }
            return _instanca;
        }

        /// <summary>
        /// Lista TV serija.
        /// </summary>
        private List<Serija> _serije = new List<Serija>();

        /// <summary>
        /// Vraća listu serija iz repozitorija.
        /// </summary>
        /// <returns>lista TV serija</returns>
        public List<Serija> dohvatiSerije()
        {
            return _serije;
        }

        /// <summary>
        /// Vraća broj serija u repozitoriju.
        /// </summary>
        public int BrojSerija
        {
            get { return _serije.Count; }
        }

        /// <summary>
        /// Provjerava postoji li serija s ID-jem inID u repozitoriju.
        /// </summary>
        /// <param name="inID">ID serije</param>
        /// <returns>rezultat provjere</returns>
        public bool serijaPostoji(int inID)
        {
            foreach(Serija serija in _serije)
            {
                if (serija.ID == inID)
                {
                    return true;
                }
            }
            return false;
        }

        public Serija dohvatiSerijuPoID(int inID)
        {
            if (serijaPostoji(inID))
            {
                foreach(Serija serija in _serije)
                {
                    if (serija.ID == inID)
                    {
                        return serija;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Dodaje novu seriju u repozitorij.
        /// </summary>
        /// <param name="serija">TV serija</param>
        public void dodajSeriju(Serija serija)
        {
            if (serijaPostoji(serija.ID))
            {
                throw new SeriesAlreadyExists();
            }
            _serije.Add(serija);
        }

        /// <summary>
        /// Uklanja seriju iz repozitorija.
        /// </summary>
        /// <param name="inID">ID serije</param>
        public void ukloniSeriju(int inID)
        {
            if (serijaPostoji(inID))
            {
                _serije.RemoveAll(x => x.ID == inID);
                return;
            }
            throw new SeriesDoesNotExist();
        }

        /// <summary>
        /// Vraća jedinstveni ID koji ne postoji u repozitoriju.
        /// </summary>
        /// <returns>ID</returns>
        public int dohvatiJedinstveniID()
        {
            int i = 0;
            while (true)
            {
                i++;
                if (serijaPostoji(i) == false)
                    break;                
            }
            return i;
        }
    }
}
