﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model.Repozitoriji
{
    public class GenreRepozitorij
    {
        /// <summary>
        /// Singleton.
        /// </summary>
        private static GenreRepozitorij _instanca = null;

        /// <summary>
        /// Vraća singleton.
        /// </summary>
        /// <returns>singleton</returns>
        public static GenreRepozitorij dohvatiInstancu()
        {
            if (_instanca == null)
            {
                _instanca = new GenreRepozitorij();
            }
            return _instanca;
        }

        /// <summary>
        /// Lista žanrova.
        /// </summary>
        private List<Genre> _genres = new List<Genre>();

        /// <summary>
        /// Vraća listu žanrova iz repozitorija.
        /// </summary>
        /// <returns>lista žanrova</returns>
        public List<Genre> dohvatiGenres()
        {
            return _genres;
        }

        /// <summary>
        /// Vraća ukupan broj žanrova u repozitoriju.
        /// </summary>
        public int brojGenres
        {
            get { return _genres.Count; }
        }

        /// <summary>
        /// Provjerava postoji li žanr s imenom inNaziv u repozitoriju.
        /// </summary>
        /// <param name="inNaziv">ime žanra</param>
        /// <returns>rezultat provjere</returns>
        public bool genrePostoji(string inNaziv)
        {
            foreach (Genre genre in _genres)
            {
                if (genre.Naziv == inNaziv)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Dodaje novi žanr u repozitorij.
        /// </summary>
        /// <param name="genre">žanr</param>
        public void dodajGenre(Genre genre)
        {
            if (genrePostoji(genre.Naziv))
            {
                throw new GenreAlreadyExists();
            }
            _genres.Add(genre);
        }

        /// <summary>
        /// Uklanja žanr iz repozitorija.
        /// </summary>
        /// <param name="inNaziv">ime žanra</param>
        public void ukloniGenre(string inNaziv)
        {
            if (genrePostoji(inNaziv))
            {
                _genres.RemoveAll(x => x.Naziv == inNaziv);
                return;
            }
            throw new GenreDoesNotExist();
        }
    }
}
