﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model.Repozitoriji
{
    public class KritikaRepozitorij
    {
        /// <summary>
        /// Singleton.
        /// </summary>
        private static KritikaRepozitorij _instanca = null;

        /// <summary>
        /// Vraća singleton.
        /// </summary>
        /// <returns>singleton</returns>
        public static KritikaRepozitorij dohvatiInstancu()
        {
            if (_instanca == null)
            {
                _instanca = new KritikaRepozitorij();
            }
            return _instanca;
        }

        /// <summary>
        /// Lista kritika.
        /// </summary>
        private List<Kritika> _kritike = new List<Kritika>();

        /// <summary>
        /// Vraća listu kritika iz repozitorija.
        /// </summary>
        /// <returns>lista kritika</returns>
        public List<Kritika> dohvatiKritike()
        {
            return _kritike;
        }

        /// <summary>
        /// Vraća kritiku iz repozitorija, inače null.
        /// </summary>
        /// <param name="inNaziv">naziv kritike</param>
        /// <returns>kritika</returns>
        public Kritika dohvatiKritikuPoNazivu(string inNaziv)
        {
            foreach(Kritika kritika in _kritike)
            {
                if (kritika.Naziv == inNaziv)
                {
                    return kritika;
                }
            }
            return null;
        }

        /// <summary>
        /// Provjerava postoji li kritika s nazivom inNaziv u repozitoriju.
        /// </summary>
        /// <param name="inNaziv">naziv kritike</param>
        /// <returns>rezultat provjere</returns>
        public bool kritikaPostoji(string inNaziv)
        {
            foreach (Kritika kritika in _kritike)
            {
                if (kritika.Naziv == inNaziv)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Uklanja kritiku s nazivom inNaziv iz repozitorija.
        /// </summary>
        /// <param name="inNaziv">naziv kritike</param>
        public void ukloniKritiku(string inNaziv)
        {
            if(kritikaPostoji(inNaziv))
            {
                _kritike.RemoveAll(x => x.Naziv == inNaziv);
                return;
            }
            throw new KritikaDoesNotExist();
        }

        /// <summary>
        /// Dodaje kritiku ili zamjenjuje postojeću iz repozitorija.
        /// </summary>
        /// <param name="kritika">kritika</param>
        public void dodajKritiku(Kritika kritika)
        {
            if(kritikaPostoji(kritika.Naziv))
            {
                ukloniKritiku(kritika.Naziv);
            }
            _kritike.Add(kritika);
        }
    }
}
