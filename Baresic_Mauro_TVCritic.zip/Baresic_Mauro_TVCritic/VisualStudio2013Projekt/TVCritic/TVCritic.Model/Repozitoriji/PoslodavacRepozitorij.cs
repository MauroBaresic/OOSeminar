﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model.Repozitoriji
{
    public class PoslodavacRepozitorij
    {
        /// <summary>
        /// Singleton.
        /// </summary>
        private static PoslodavacRepozitorij _instanca = null;

        /// <summary>
        /// Vraća singleton.
        /// </summary>
        /// <returns>singleton</returns>
        public static PoslodavacRepozitorij dohvatiInstancu()
        {
            if (_instanca == null)
            {
                _instanca = new PoslodavacRepozitorij();
            }
            return _instanca;
        }

        /// <summary>
        /// Lista poslodavaca.
        /// </summary>
        private List<Poslodavac> _poslodavci = new List<Poslodavac>();

        /// <summary>
        /// Vraća listu poslodavaca iz repozitorija.
        /// </summary>
        /// <returns>lista poslodavaca</returns>
        public List<Poslodavac> dohvatiPoslodavce()
        {
            return _poslodavci;
        }

        /// <summary>
        /// Provjerava postoji li poslodavac s nazivom inNaziv u repozitoriju.
        /// </summary>
        /// <param name="inNaziv">naziv poslodavca</param>
        /// <returns>rezultat provjere</returns>
        public bool poslodavacPostoji(string inNaziv)
        {
            foreach(Poslodavac poslodavac in _poslodavci)
            {
                if(poslodavac.Naziv == inNaziv)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Dodaje poslodavca u repozitorij.
        /// </summary>
        /// <param name="poslodavac">poslodavac</param>
        public void dodajPoslodavca(Poslodavac poslodavac)
        {
            if (poslodavacPostoji(poslodavac.Naziv))
            {
                throw new PoslodavacAlreadyExists();
            }
            _poslodavci.Add(poslodavac);
        }

        /// <summary>
        /// Uklanja poslodavca s nazivom INaziv iz repozitorija.
        /// </summary>
        /// <param name="inNaziv">naziv poslodavca</param>
        public void ukloniPoslodavca(string inNaziv)
        {
            if (poslodavacPostoji(inNaziv))
            {
                _poslodavci.RemoveAll(x => x.Naziv == inNaziv);
                return;
            }
            throw new PoslodavacDoesNotExist();
        }
    }
}
