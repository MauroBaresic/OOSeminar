﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    [Serializable]
    public class TVCriticBaseException : Exception
    {
    }

    [Serializable]
    public class GenreAlreadyExists : TVCriticBaseException
    {
 
    }

    [Serializable]
    public class GenreDoesNotExist : TVCriticBaseException
    {

    }

    [Serializable]
    public class SeasonAlreadyExists : TVCriticBaseException
    {

    }

    [Serializable]
    public class SeasonDoesNotExist : TVCriticBaseException
    {

    }

    [Serializable]
    public class EpisodeAlreadyExists : TVCriticBaseException
    {

    }

    [Serializable]
    public class EpisodeDoesNotExist : TVCriticBaseException
    {

    }

    [Serializable]
    public class SeriesAlreadyExists : TVCriticBaseException
    {

    }

    [Serializable]
    public class SeriesDoesNotExist : TVCriticBaseException
    {

    }

    [Serializable]
    public class PoslodavacAlreadyExists : TVCriticBaseException
    {

    }

    [Serializable]
    public class PoslodavacDoesNotExist : TVCriticBaseException
    {

    }

    [Serializable]
    public class KritikaDoesNotExist : TVCriticBaseException
    {

    }

}
