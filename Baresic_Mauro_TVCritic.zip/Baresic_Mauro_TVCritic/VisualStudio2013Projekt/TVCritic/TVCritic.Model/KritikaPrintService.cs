﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TVCritic.Model
{
    public class KritikaPrintService
    {
        /// <summary>
        /// Ispisuje kritiku u svim potrebnim formatima.
        /// </summary>
        /// <param name="path">path</param>
        /// <param name="kritika">kritika</param>
        public static void ispis(string path, Kritika kritika)
        {
            foreach(Poslodavac poslodavac in kritika.Poslodavci)
            {
                string tekstKritika = KritikaPrintService.pretvoriUNoviFormat(kritika.TekstKritike, poslodavac.FormatKritike);
                File.WriteAllText(path + poslodavac.FormatKritike, tekstKritika);
            }
        }
        
        /// <summary>
        /// Simulira pretvorbu u novi format.
        /// </summary>
        /// <param name="inTekst">tekst kritike</param>
        /// <param name="inFormat">novi format kritike</param>
        /// <returns>tekst kritike u novom formatu</returns>
        private static string pretvoriUNoviFormat(string inTekst, string inFormat)
        {
            //Samo simulira pretvorbu u novi format.
            return inTekst;
        }
    }
}
