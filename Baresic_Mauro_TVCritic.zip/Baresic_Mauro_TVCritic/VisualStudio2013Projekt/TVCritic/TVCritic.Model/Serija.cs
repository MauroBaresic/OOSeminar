﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    /// <summary>
    /// Klasa koja predstavlja TV seriju.
    /// </summary>
    public class Serija
    {
        /// <summary>
        /// ID serije
        /// </summary>
        private int _id;

        /// <summary>
        /// Dohvaća ID serije.
        /// </summary>
        public int ID
        {
            get { return _id; }
        }

        /// <summary>
        /// Ime serije.
        /// </summary>
        private string _naziv;

        /// <summary>
        /// Vraća i postavlja ime serije.
        /// </summary>
        public string Naziv 
        {
            get { return _naziv; }
            set { _naziv = value; } 
        }

        /// <summary>
        /// Godina prvog prikazivanja.
        /// </summary>
        private int _godina;

        /// <summary>
        /// Vraća i postavlja godinu prvog prikazivanja.
        /// </summary>
        public int Godina 
        {
            get { return _godina; }
            set { _godina = value; }
        }

        /// <summary>
        /// Ocjena epizode.
        /// </summary>
        private int _ocjena = 0;

        /// <summary>
        /// Vraća i postavlja ocjenu epizode.
        /// </summary>
        public int Ocjena
        {
            get { return _ocjena; }
            set { _ocjena = value; }
        }

        /// <summary>
        /// Lista žanrova kojima serija pripada.
        /// </summary>
        private List<Genre> _genres = new List<Genre>();

        /// <summary>
        /// Dohvaća listu žanrova kojima serija pripada.
        /// </summary>
        /// <returns>Lista žanrova</returns>
        public List<Genre> dohvatiGenres()
        {
            return _genres;
        }

        /// <summary>
        /// Pridružuje žanr seriji.
        /// </summary>
        /// <param name="inGenre">Žanr</param>
        public void dodajGenre(Genre inGenre)
        {
            foreach(Genre genre in _genres)
            {
                // ako je žanr već dodan
                if (genre.Naziv == inGenre.Naziv)
                {
                    throw new GenreAlreadyExists();
                }
            }
            _genres.Add(inGenre);
        }

        /// <summary>
        /// Lista sezona serije.
        /// </summary>
        private List<Sezona> _sezone = new List<Sezona>();

        /// <summary>
        /// Vraća listu sezona.
        /// </summary>
        /// <returns></returns>
        public List<Sezona> dohvatiSezone()
        {
            return _sezone;
        }

        /// <summary>
        /// Provjerava postoji li sezona u seriji.
        /// </summary>
        /// <param name="inRedniBroj">redni broj sezone</param>
        /// <returns>rezultat provjere</returns>
        public bool sezonaPostoji(int inRedniBroj)
        {
            foreach (Sezona sezona in _sezone)
            {
                if (sezona.RedniBroj == inRedniBroj)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Dodaje sezonu u seriju.
        /// </summary>
        /// <param name="inSezona">sezona</param>
        public void dodajSezonu(Sezona inSezona)
        {
            if (sezonaPostoji(inSezona.RedniBroj))
            {
                throw new SeasonAlreadyExists();
            }
            _sezone.Add(inSezona);
        }

        /// <summary>
        /// Uklanja sezonu iz serije.
        /// </summary>
        /// <param name="inRedniBroj">redni broj sezone</param>
        public void ukloniSezonu(int inRedniBroj)
        {
            if (sezonaPostoji(inRedniBroj))
            {
                _sezone.RemoveAll(x => x.RedniBroj == inRedniBroj);
                return;
            }
            throw new SeasonDoesNotExist();
        }

        /// <summary>
        /// Flag koji služi za omogućavanje kritiziranja serije.
        /// </summary>
        private bool _kritikaEnabled = true;

        /// <summary>
        /// Vraća i postavlja mogućnost kritiziranja.
        /// </summary>
        public bool KritikaEnabled
        {
            get { return _kritikaEnabled; }
            set { _kritikaEnabled = value; }
        }

        /// <summary>
        /// Računa ocjenu sezone.
        /// </summary>
        /// <returns>ocjena</returns>
        public double izracunajOcjenu()
        {
            if (this.KritikaEnabled)
            {
                double suma = 0.0;
                int brojSezona = 0;
                foreach(Sezona sezona in _sezone)
                {
                    if (sezona.izracunajOcjenu(TipOcjene.AVG) > 0)
                    {
                        suma += sezona.izracunajOcjenu(TipOcjene.AVG);
                        brojSezona++;
                    }
                }
                if (brojSezona != 0)
                {
                    return Math.Round(suma / brojSezona, 2);
                }
                else
                {
                    return 0.0;
                }
            }
            // tip računanja single
            return this.Ocjena;
        }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        /// <param name="inID">ID serije</param>
        /// <param name="inGodina">godina početka prikazivanja</param>
        /// <param name="inNaziv">naziv serije</param>
        public Serija(int inID, int inGodina, string inNaziv)
        {
            this._id = inID;
            this._godina = inGodina;
            this._naziv = inNaziv;
        }
    }


    /// <summary>
    /// tip izračuna ocjene
    /// </summary>
    public enum TipOcjene { AVG, Single };
}
