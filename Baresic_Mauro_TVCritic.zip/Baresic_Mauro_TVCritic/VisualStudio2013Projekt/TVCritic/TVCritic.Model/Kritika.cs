﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    /// <summary>
    /// Klasa koja predstavlja kritiku.
    /// </summary>
    public class Kritika
    {
        /// <summary>
        /// Naziv kritike.
        /// </summary>
        private string _naziv;

        /// <summary>
        /// Vraća i postavlja naziv kritike.
        /// </summary>
        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }

        /// <summary>
        /// Lista poslodavaca za koje se kritika piše.
        /// </summary>
        private List<Poslodavac> _poslodavci = null;

        /// <summary>
        /// Vraća listu poslodavaca za koje se kritika piše.
        /// </summary>
        public List<Poslodavac> Poslodavci
        {
            get { return _poslodavci; }
        }

        /// <summary>
        /// Tekst(sadržaj) kritike.
        /// </summary>
        private string _tekstKritike;

        /// <summary>
        /// Vraća tekst kritike.
        /// </summary>
        public string TekstKritike
        {
            get { return _tekstKritike; }
            set { _tekstKritike = value; }
        }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        /// <param name="inNaziv">naziv kritike</param>
        /// <param name="inPoslodavci">lista poslodavaca</param>
        /// <param name="inTekst">tekst kritike</param>
        public Kritika(string inNaziv, List<Poslodavac> inPoslodavci, string inTekst)
        {
            this._naziv = inNaziv;
            this._poslodavci = inPoslodavci;
            this._tekstKritike = inTekst;
        }
    }
}
