﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    /// <summary>
    /// Klasa koja predstavlja žanr.
    /// </summary>
    public class Genre
    {
        /// <summary>
        /// Ime žanra.
        /// </summary>
        private string _naziv;

        /// <summary>
        /// Vraća ime žanra.
        /// </summary>
        public string Naziv
        {
            get { return _naziv; }
        }

        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="inName">Ime žanra</param>
        public Genre(string inNaziv)
        {
            this._naziv = inNaziv;
        }
    }
}
