﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    /// <summary>
    /// Klasa koja predstavlja jednu epizodu serije.
    /// </summary>
    public class Epizoda
    {
        /// <summary>
        /// ID serije kojoj epizoda pripada.
        /// </summary>
        private int _idSerija;

        /// <summary>
        /// Vraća ID serije kojoj epizoda pripada.
        /// </summary>
        public int IDSerija
        {
            get { return _idSerija; }
        }

        /// <summary>
        /// Redni broj sezone kojoj epizoda pripada.
        /// </summary>
        private int _idSezona;

        /// <summary>
        /// Vraća i postavlja redni broj sezone kojoj epizoda pripada.
        /// </summary>
        public int IDSezona
        {
            get { return _idSezona; }
            set { _idSezona = value; }
        }

        /// <summary>
        /// Ime epizode.
        /// </summary>
        private string _naziv;

        /// <summary>
        /// Vraća i postavlja ime epizode.
        /// </summary>
        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }

        /// <summary>
        /// Redni broj epizode u određenoj sezoni serije.
        /// </summary>
        private int _redniBroj;

        /// <summary>
        /// Vraća i postavlja redni broj epizode.
        /// </summary>
        public int RedniBroj
        {
            get { return _redniBroj; }
            set { _redniBroj = value; }
        }

        /// <summary>
        /// Datum prvog prikazivanja.
        /// </summary>
        private DateTime _datum;

        /// <summary>
        /// Vraća i postavlja datum prvog prikazivanja.
        /// </summary>
        public DateTime Datum
        {
            get { return _datum; }
            set { _datum = value; }
        }

        /// <summary>
        /// Ocjena epizode.
        /// </summary>
        private int _ocjena = 0;

        /// <summary>
        /// Vraća i postavlja ocjenu epizode.
        /// </summary>
        public int Ocjena
        {
            get { return _ocjena; }
            set { _ocjena = value; }
        }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        /// <param name="inIDSerija">ID serije kojoj epizoda pripada</param>
        /// <param name="inIDSezona">ID sezone kojoj epizoda pripada</param>
        /// <param name="inRedniBroj">redni broj epizode</param>
        /// <param name="inNaziv">ime epizode</param>
        /// <param name="inDatum">datum prvog prikazivanja</param>
        public Epizoda(int inIDSerija, int inIDSezona, int inRedniBroj, string inNaziv, DateTime inDatum)
        {
            this._idSerija = inIDSerija;
            this._idSezona = inIDSezona;
            this._redniBroj = inRedniBroj;
            this._naziv = inNaziv;
            this._datum = inDatum;
        }
    }
}
