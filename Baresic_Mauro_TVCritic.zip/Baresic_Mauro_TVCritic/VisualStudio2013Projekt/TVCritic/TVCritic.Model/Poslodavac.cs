﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    /// <summary>
    /// Klasa koja predstavlja poslodavca.
    /// </summary>
    public class Poslodavac
    {
        /// <summary>
        /// Naziv poslodavca.
        /// </summary>
        private string _naziv;

        /// <summary>
        /// Vraća i postavlja naziv poslodavca.
        /// </summary>
        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }

        /// <summary>
        /// Format kritike potreban poslodavcu.
        /// </summary>
        private string _formatKritike;

        /// <summary>
        /// Vraća i postavlja format kritike.
        /// </summary>
        public string FormatKritike
        {
            get { return _formatKritike; }
            set { _formatKritike = value; }
        }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        /// <param name="inNaziv">naziv poslodavca</param>
        /// <param name="inFormatKritike">format kritike</param>
        public Poslodavac(string inNaziv, string inFormatKritike)
        {
            this._naziv = inNaziv;
            this._formatKritike = inFormatKritike;
        }
    }
}
