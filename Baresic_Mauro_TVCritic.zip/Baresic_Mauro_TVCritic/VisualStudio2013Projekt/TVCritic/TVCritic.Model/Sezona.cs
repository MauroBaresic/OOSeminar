﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Model
{
    /// <summary>
    /// Klasa koja predstavlja sezonu serije.
    /// </summary>
    public class Sezona
    {
        /// <summary>
        /// ID serije kojoj sezona pripada.
        /// </summary>
        private int _idSerija;

        /// <summary>
        /// Vraća ID serije kojoj sezona pripada.
        /// </summary>
        public int IDSerija
        {
            get { return _idSerija; }
        }

        /// <summary>
        /// Ime sezone.
        /// </summary>
        private string _naziv;

        /// <summary>
        /// Vraća i postavlja ime sezone.
        /// </summary>
        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }

        /// <summary>
        /// Redni broj sezone u seriji.
        /// </summary>
        private int _redniBroj;

        /// <summary>
        /// Vraća i postavlja redni broj sezone.
        /// </summary>
        public int RedniBroj
        {
            get { return _redniBroj; }
            set { _redniBroj = value; }
        }

        /// <summary>
        /// Godina početka prikazivanja sezone.
        /// </summary>
        private int _godina;

        /// <summary>
        /// Vraća i postavlja godinu početka prikazivanja sezone.
        /// </summary>
        public int Godina
        {
            get { return _godina; }
            set { _godina = value; }
        }

        /// <summary>
        /// Ocjena epizode.
        /// </summary>
        private int _ocjena = 0;

        /// <summary>
        /// Vraća i postavlja ocjenu epizode.
        /// </summary>
        public int Ocjena
        {
            get { return _ocjena; }
            set { _ocjena = value; }
        }

        /// <summary>
        /// Lista epizoda u sezoni.
        /// </summary>
        private List<Epizoda> _epizode = new List<Epizoda>();

        /// <summary>
        /// Dohvati listu epizoda u sezoni.
        /// </summary>
        /// <returns></returns>
        public List<Epizoda> dohvatiEpizode()
        {
            return _epizode;
        }

        /// <summary>
        /// Provjerava postoji li epizoda u sezoni.
        /// </summary>
        /// <param name="inRedniBroj">redni broj</param>
        /// <returns>rezultat provjere</returns>
        public bool epizodaPostoji(int inRedniBroj)
        {
            foreach (Epizoda epizoda in _epizode)
            {
                if (epizoda.RedniBroj == inRedniBroj)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Dodaje epizodu u sezonu.
        /// </summary>
        /// <param name="inEpizoda">epizoda</param>
        public void dodajEpizodu(Epizoda inEpizoda)
        {
            if (epizodaPostoji(inEpizoda.RedniBroj))
            {
                throw new EpisodeAlreadyExists();
            }
            _epizode.Add(inEpizoda);
        }

        /// <summary>
        /// Uklanja epizodu iz sezone.
        /// </summary>
        /// <param name="inRedniBroj">redni broj epizode</param>
        public void ukloniEpizodu(int inRedniBroj)
        {
            if (epizodaPostoji(inRedniBroj))
            {
                _epizode.RemoveAll(x => x.RedniBroj == inRedniBroj);
                return;
            }
            throw new EpisodeDoesNotExist();
        }

        /// <summary>
        /// Vraća ukupan broj epizoda u sezoni.
        /// </summary>
        public int BrojEpizoda
        {
            get { return _epizode.Count; }
        }

        /// <summary>
        /// Računa ocjenu sezone
        /// </summary>
        /// <param name="tipOcjene">tip računanja</param>
        /// <returns>ocjena</returns>
        public double izracunajOcjenu(TipOcjene tipOcjene)
        {
            //računa prosjek ocjena epizoda
            if (tipOcjene == TipOcjene.AVG)
            {
                double suma = 0.0;
                int brojEpizoda = 0;
                foreach (Epizoda epizoda in _epizode)
                {
                    if (epizoda.Ocjena > 0)
                    {
                        suma += epizoda.Ocjena;
                        brojEpizoda++;
                    }
                }
                if (brojEpizoda != 0)
                {
                    return Math.Round(suma / brojEpizoda, 2);
                }
                else
                {
                    return 0.0;
                }
            }
            // tipOcjene == Single, direktno vraća ocjenu
            return this.Ocjena;
        }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        /// <param name="inID">ID serije kojoj sezona pripada</param>
        /// <param name="inGodina">godina početka prikazivanja sezone</param>
        /// <param name="inRedniBroj">redni broj sezone</param>
        /// <param name="inNaziv">naziv sezone</param>
        public Sezona(int inID, int inGodina, int inRedniBroj, string inNaziv)
        {
            this._idSerija = inID;
            this._godina = inGodina;
            this._redniBroj = inRedniBroj;
            this._naziv = inNaziv;
        }
    }

}
