﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Common;

namespace TVCritic.Main
{
    public partial class AddEpisodeForm : Form, IAddEpisode
    {
        public AddEpisodeForm()
        {
            InitializeComponent();
        }

        public bool ShowForm()
        {
            if(this.ShowDialog() == DialogResult.OK)
            { 
                return true;
            }
            return false;
        }

        public string Naziv
        {
            get { return NazivTxtBox.Text; }
        }

        public string RedniBroj
        {
            get { return RedniBrojTxtBox.Text; }
        }

        public DateTime Datum
        {
            get { return dateTimePicker1.Value; }
        }
    }
}
