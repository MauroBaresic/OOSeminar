﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Controllers;
using TVCritic.Common;
using TVCritic.Model;

using TVCritic.Model.Repozitoriji;

namespace TVCritic.Main
{
    public partial class MainForm : Form, Observer
    {
        public MainForm()
        {
            InitializeComponent();

            _criticController.NapuniRepozitorij();
            _criticController.addObserver(this);
            RefreshEpisodes();
        }

        private CriticController _criticController = new CriticController();


        private void PregledSerijaButton_Click(object sender, EventArgs e)
        {
            IPregledSerijaForm psf = new PregledSerijaForm(_criticController);
            _criticController.prikaziSerije(psf);
        }

        private void ListBox_Click(object sender, EventArgs e)
        {
            
        }

        private void ListBox_MouseLeave(object sender, EventArgs e)
        {
            (sender as ListBox).SelectedIndex = -1;
        }

        private void RefreshEpisodes()
        {
            List<Epizoda> jucer = _criticController.dohvatiEpizodeOdJucer();
            List<Epizoda> danas = _criticController.dohvatiEpizodeOdDanas();
            List<Epizoda> sutra = _criticController.dohvatiEpizodeOdSutra();

            JucerListBox.Items.Clear();
            foreach (Epizoda ep in jucer)
            {
                string naziv = _criticController.dohvatiKratkiNazivEpizode(ep.IDSerija, ep.IDSezona, ep.RedniBroj);
                if (naziv == "")
                    naziv = ep.Naziv;
                JucerListBox.Items.Add(new EpizodaListBoxItem(naziv, ep));
            }

            DanasListBox.Items.Clear();
            foreach (Epizoda ep in danas)
            {
                string naziv = _criticController.dohvatiKratkiNazivEpizode(ep.IDSerija, ep.IDSezona, ep.RedniBroj);
                if (naziv == "")
                    naziv = ep.Naziv;
                DanasListBox.Items.Add(new EpizodaListBoxItem(naziv, ep));
            }

            SutraListBox.Items.Clear();
            foreach (Epizoda ep in sutra)
            {
                string naziv = _criticController.dohvatiKratkiNazivEpizode(ep.IDSerija, ep.IDSezona, ep.RedniBroj);
                if (naziv == "")
                    naziv = ep.Naziv;
                SutraListBox.Items.Add(new EpizodaListBoxItem(naziv, ep));
            }
        }

        private void JucerListBox_DoubleClick(object sender, EventArgs e)
        {
            if ((sender as ListBox).SelectedItem == null)
                return;
            Epizoda ep = ((EpizodaListBoxItem)(sender as ListBox).SelectedItem).epizoda;

            IEpizodaForm ef = new EpizodaForm(_criticController, ep.IDSerija, ep.IDSezona, ep.RedniBroj);
            _criticController.prikaziEpizodu(ef);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RefreshEpisodes();
        }

        public void UpdateObserver()
        {
            RefreshEpisodes();
        }
    }
}
