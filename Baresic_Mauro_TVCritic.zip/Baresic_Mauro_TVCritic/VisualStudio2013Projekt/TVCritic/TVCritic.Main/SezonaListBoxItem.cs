﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TVCritic.Model;

namespace TVCritic.Main
{
    public class SezonaListBoxItem
    {
        public string Naziv = "";
        public Sezona sezona = null;

        public override string ToString()
        {
            return Naziv;
        }

        public SezonaListBoxItem(string naziv, Sezona s)
        {
            Naziv = naziv;
            sezona = s;
        }
    }
}
