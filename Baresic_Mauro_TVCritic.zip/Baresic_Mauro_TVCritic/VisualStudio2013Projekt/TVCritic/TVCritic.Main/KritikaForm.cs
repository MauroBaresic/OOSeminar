﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Common;
using TVCritic.Model;
using TVCritic.Controllers;

namespace TVCritic.Main
{
    public partial class KritikaForm : Form, IKritikaForm
    {
        public KritikaForm(CriticController inController, string naziv, string ocjena)
        {
            InitializeComponent();
            _criticController = inController;
            NazivKritikeLabel.Text = naziv;
            OcjenaLabel.Text = ocjena;
        }
        private CriticController _criticController = null;

        private string _path = "";

        private List<Poslodavac> _poslodavci = new List<Poslodavac>();


        private void SaveButton_Click(object sender, EventArgs e)
        {
            if(DialogResult.OK == saveFileDialog1.ShowDialog())
            {
                _path = saveFileDialog1.FileName;
            }
        }


        public bool ShowForm()
        {
            if (this.ShowDialog() == DialogResult.OK)
            {
                return true;
            }
            return false;
        }

        public string Naziv
        {
            get { return NazivKritikeLabel.Text; } 
        }


        public string Tekst
        {
            get { return KritikaTextBox.Text; }
        }

        public string PathKritika
        {
            get { return _path; }
        }

        public List<Poslodavac> Poslodavci
        {
            get { return _poslodavci; }
        }

        private void PoslodavacDodajButton_Click(object sender, EventArgs e)
        {
            if (_criticController == null) return;
            IAddPoslodavac addP = new AddPoslodavacForm();
            Poslodavac p = _criticController.dodajPoslodavca(addP);
            if (p == null) return;
            _poslodavci.Add(p);
            PoslodavciListBox.Items.Add(p.Naziv);

        }

        private void PoslodavacUkloniButton_Click(object sender, EventArgs e)
        {
            if (PoslodavciListBox.SelectedItem == null) return;
            string naziv = PoslodavciListBox.SelectedItem.ToString();
            _poslodavci.RemoveAll(x => x.Naziv == naziv);
            PoslodavciListBox.Items.RemoveAt(PoslodavciListBox.SelectedIndex);
        }
    }
}
