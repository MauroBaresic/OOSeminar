﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Model;
using TVCritic.Common;
using TVCritic.Controllers;

using TVCritic.Model.Repozitoriji;

namespace TVCritic.Main
{
    public partial class PregledSerijaForm : Form, IPregledSerijaForm
    {
        public PregledSerijaForm(CriticController inController)
        {
            InitializeComponent();
            _criticController = inController;            

            RefreshSeries();
        }

        private CriticController _criticController = null;

        private void SerijeListBox_Click(object sender, EventArgs e)
        {
            
        }

        private void SerijeListBox_DoubleClick(object sender, EventArgs e)
        {
            if ((sender as ListBox).SelectedItem == null)
                return;
            Serija s = ((SerijaListBoxItem)(sender as ListBox).SelectedItem).serija;

            ISerijaForm sf = new SerijaForm(_criticController, s.ID);
            _criticController.prikaziSezone(sf);
        }

        public void RefreshSeries()
        {
            if (_criticController == null)
                return;
            List<Serija> serije = _criticController.dohvatiSerije();
            SerijeListBox.Items.Clear();
            foreach (Serija s in serije)
            {
                SerijeListBox.Items.Add(new SerijaListBoxItem(s.Naziv + " ("+s.Godina.ToString()+")", s));
            }
        }

        public bool ShowForm()
        {
            this.Show();

            return true;
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            IAddSeries addS = new AddSeriesForm();
            _criticController.dodajSeriju(addS);
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            if (SerijeListBox.SelectedItem == null) return;
            _criticController.ukloniSeriju(((SerijaListBoxItem)SerijeListBox.SelectedItem).serija.ID);
        }

        public void UpdateObserver()
        {
            RefreshSeries();
        }

    }
}
