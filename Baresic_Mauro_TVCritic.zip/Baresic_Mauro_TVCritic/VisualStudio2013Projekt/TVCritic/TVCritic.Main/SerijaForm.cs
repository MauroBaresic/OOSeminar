﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Model;
using TVCritic.Common;
using TVCritic.Controllers;

using TVCritic.Model.Repozitoriji;

namespace TVCritic.Main
{
    public partial class SerijaForm : Form, ISerijaForm
    {
        public SerijaForm(CriticController inController, int inSerijaID)
        {
            InitializeComponent();
            _criticController = inController;            

            numericUpDown1.Value = _criticController.dohvatiOcjenuSerije(inSerijaID);
            checkBox1.Checked = _criticController.dohvatiKritikaEnabledSerije(inSerijaID);

            _serijaID = inSerijaID;

            RefreshSeasons();
        }

        private CriticController _criticController = null;

        private int _serijaID = -1;

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (_criticController == null || _serijaID == -1)
                return;
            bool value1 = (sender as CheckBox).Checked;
            _criticController.postaviKritikaEnabledSerije(_serijaID, value1);
        }

        private void RefreshSeasons()
        {
            if (_criticController == null || _serijaID == -1)
                return;
            this.Text = _criticController.dohvatiNazivSerije(_serijaID);
            numericUpDown1.Value = _criticController.dohvatiOcjenuSerije(_serijaID);
            checkBox1.Checked = _criticController.dohvatiKritikaEnabledSerije(_serijaID);
            List<Sezona> sezone = _criticController.dohvatiSezone(_serijaID);

            SezoneListBox.Items.Clear();
            foreach(Sezona s in sezone)
            {
                SezoneListBox.Items.Add(new SezonaListBoxItem("S"+s.RedniBroj.ToString() + "\t" + s.Naziv + " ("+s.Godina.ToString()+")",s));
            }

        }

        private void SezoneListBox_Click(object sender, EventArgs e)
        {
            
        }
        private void SezoneListBox_DoubleClick(object sender, EventArgs e)
        {
            if ((sender as ListBox).SelectedItem == null) return;
            Sezona sezona = ((SezonaListBoxItem)(sender as ListBox).SelectedItem).sezona;

            ISezonaForm sf = new SezonaForm(_criticController, sezona.IDSerija, sezona.RedniBroj);
            _criticController.prikaziEpizode(sf);
        }

        public bool ShowForm()
        {
            this.Show();
            return true;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (_criticController == null || _serijaID == -1)
                return;
            _criticController.postaviOcjenuSerije(_serijaID, (int)(sender as NumericUpDown).Value);
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            if (SezoneListBox.SelectedItem == null) return;
            Sezona s = ((SezonaListBoxItem)(SezoneListBox.SelectedItem)).sezona;
            _criticController.ukloniSezonu(s.IDSerija, s.RedniBroj);
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            IAddSeason addS = new AddSeasonForm();
            _criticController.dodajSezonu(addS, _serijaID);
        }

        public void UpdateObserver()
        {
            RefreshSeasons();
        }
    }
}
