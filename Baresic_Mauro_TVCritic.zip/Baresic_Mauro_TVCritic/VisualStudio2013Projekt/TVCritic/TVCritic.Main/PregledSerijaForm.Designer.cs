﻿namespace TVCritic.Main
{
    partial class PregledSerijaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SerijeListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDodajSeriju = new System.Windows.Forms.Button();
            this.btnUkloniSeriju = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SerijeListBox
            // 
            this.SerijeListBox.FormattingEnabled = true;
            this.SerijeListBox.Location = new System.Drawing.Point(12, 48);
            this.SerijeListBox.Name = "SerijeListBox";
            this.SerijeListBox.Size = new System.Drawing.Size(580, 329);
            this.SerijeListBox.TabIndex = 0;
            this.SerijeListBox.Click += new System.EventHandler(this.SerijeListBox_Click);
            this.SerijeListBox.DoubleClick += new System.EventHandler(this.SerijeListBox_DoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Serije koje se prate:";
            // 
            // btnDodajSeriju
            // 
            this.btnDodajSeriju.Location = new System.Drawing.Point(436, 19);
            this.btnDodajSeriju.Name = "btnDodajSeriju";
            this.btnDodajSeriju.Size = new System.Drawing.Size(75, 23);
            this.btnDodajSeriju.TabIndex = 2;
            this.btnDodajSeriju.Text = "Dodaj";
            this.btnDodajSeriju.UseVisualStyleBackColor = true;
            this.btnDodajSeriju.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnUkloniSeriju
            // 
            this.btnUkloniSeriju.Location = new System.Drawing.Point(517, 19);
            this.btnUkloniSeriju.Name = "btnUkloniSeriju";
            this.btnUkloniSeriju.Size = new System.Drawing.Size(75, 23);
            this.btnUkloniSeriju.TabIndex = 3;
            this.btnUkloniSeriju.Text = "Ukloni";
            this.btnUkloniSeriju.UseVisualStyleBackColor = true;
            this.btnUkloniSeriju.Click += new System.EventHandler(this.btnUkloni_Click);
            // 
            // PregledSerijaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 394);
            this.Controls.Add(this.btnUkloniSeriju);
            this.Controls.Add(this.btnDodajSeriju);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SerijeListBox);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PregledSerijaForm";
            this.Text = "Pregled serija";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox SerijeListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDodajSeriju;
        private System.Windows.Forms.Button btnUkloniSeriju;
    }
}