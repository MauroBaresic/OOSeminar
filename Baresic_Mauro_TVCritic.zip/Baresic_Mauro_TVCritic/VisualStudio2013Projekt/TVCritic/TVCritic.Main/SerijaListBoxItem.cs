﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TVCritic.Model;

namespace TVCritic.Main
{
    public class SerijaListBoxItem
    {
        public string Naziv = "";
        public Serija serija = null;

        public override string ToString()
        {
            return Naziv;
        }

        public SerijaListBoxItem(string naziv, Serija s)
        {
            Naziv = naziv;
            serija = s;
        }
    }
}
