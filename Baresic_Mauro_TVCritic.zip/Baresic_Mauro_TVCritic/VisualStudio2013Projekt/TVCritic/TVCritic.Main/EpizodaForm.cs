﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Model;
using TVCritic.Common;
using TVCritic.Controllers;

using TVCritic.Model.Repozitoriji;

namespace TVCritic.Main
{
    public partial class EpizodaForm : Form, IEpizodaForm
    {
        public EpizodaForm(CriticController inController, int inSerijaID, int inSezonaID, int inRedniBroj)
        {
            InitializeComponent();

            _criticController = inController;

            OcjenaEpizode.Value = _criticController.dohvatiOcjenuEpizode(inSerijaID, inSezonaID, inRedniBroj);
            _serijaID = inSerijaID;
            _sezonaID = inSezonaID;
            _redniBroj = inRedniBroj;

            RefreshView();

        }
        private CriticController _criticController = null;

        private int _serijaID = -1;

        private int _sezonaID = -1;

        private int _redniBroj = -1;

        public bool ShowForm()
        {
            this.Show();
            return true;
        }

        private void RefreshView()
        {
            if (_criticController == null || _serijaID == -1 || _sezonaID == -1 || _redniBroj == -1) return;
            OcjenaEpizode.Value = _criticController.dohvatiOcjenuEpizode(_serijaID, _sezonaID, _redniBroj);
            this.Text = _criticController.dohvatiNazivSerije(_serijaID) + " - S" + _sezonaID.ToString() + "E" + _redniBroj.ToString();
        }

        private void OcjenaEpizode_ValueChanged(object sender, EventArgs e)
        {
            if (_criticController == null || _serijaID == -1 || _sezonaID == -1 || _redniBroj == -1) return;
            _criticController.postaviOcjenuEpizode(_serijaID, _sezonaID, _redniBroj, (int)OcjenaEpizode.Value);
        }

        private void NapisiKritikuButton_Click(object sender, EventArgs e)
        {
            if (_criticController == null || _serijaID == -1 || _sezonaID == -1 || _redniBroj == -1) return;
            IKritikaForm kf = new KritikaForm(_criticController, this.Text, _criticController.izracunajOcjenu(_serijaID));
            _criticController.prikaziKritiku(kf);
        }
    }
}
