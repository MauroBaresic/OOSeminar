﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TVCritic.Model;

namespace TVCritic.Main
{
    public class EpizodaListBoxItem
    {
        public string Naziv = "";
        public Epizoda epizoda = null;

        public override string ToString()
        {
            return Naziv;
        }

        public EpizodaListBoxItem(string naziv, Epizoda ep)
        {
            Naziv = naziv;
            epizoda = ep;
        }
    }
}
