﻿namespace TVCritic.Main
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PregledSerijaButton = new System.Windows.Forms.Button();
            this.JucerListBox = new System.Windows.Forms.ListBox();
            this.DanasListBox = new System.Windows.Forms.ListBox();
            this.SutraListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PregledSerijaButton
            // 
            this.PregledSerijaButton.Location = new System.Drawing.Point(13, 13);
            this.PregledSerijaButton.Name = "PregledSerijaButton";
            this.PregledSerijaButton.Size = new System.Drawing.Size(105, 23);
            this.PregledSerijaButton.TabIndex = 0;
            this.PregledSerijaButton.Text = "Pregled serija";
            this.PregledSerijaButton.UseVisualStyleBackColor = true;
            this.PregledSerijaButton.Click += new System.EventHandler(this.PregledSerijaButton_Click);
            // 
            // JucerListBox
            // 
            this.JucerListBox.FormattingEnabled = true;
            this.JucerListBox.Location = new System.Drawing.Point(132, 105);
            this.JucerListBox.Name = "JucerListBox";
            this.JucerListBox.Size = new System.Drawing.Size(210, 316);
            this.JucerListBox.TabIndex = 1;
            this.JucerListBox.Click += new System.EventHandler(this.ListBox_Click);
            this.JucerListBox.DoubleClick += new System.EventHandler(this.JucerListBox_DoubleClick);
            this.JucerListBox.MouseLeave += new System.EventHandler(this.ListBox_MouseLeave);
            // 
            // DanasListBox
            // 
            this.DanasListBox.FormattingEnabled = true;
            this.DanasListBox.Location = new System.Drawing.Point(376, 105);
            this.DanasListBox.Name = "DanasListBox";
            this.DanasListBox.Size = new System.Drawing.Size(210, 316);
            this.DanasListBox.TabIndex = 2;
            this.DanasListBox.Click += new System.EventHandler(this.ListBox_Click);
            this.DanasListBox.DoubleClick += new System.EventHandler(this.JucerListBox_DoubleClick);
            this.DanasListBox.MouseLeave += new System.EventHandler(this.ListBox_MouseLeave);
            // 
            // SutraListBox
            // 
            this.SutraListBox.FormattingEnabled = true;
            this.SutraListBox.Location = new System.Drawing.Point(619, 105);
            this.SutraListBox.Name = "SutraListBox";
            this.SutraListBox.Size = new System.Drawing.Size(210, 316);
            this.SutraListBox.TabIndex = 3;
            this.SutraListBox.Click += new System.EventHandler(this.ListBox_Click);
            this.SutraListBox.DoubleClick += new System.EventHandler(this.JucerListBox_DoubleClick);
            this.SutraListBox.MouseLeave += new System.EventHandler(this.ListBox_MouseLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(132, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Epizode emitirane jučer:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(376, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Epizode emitirane danas:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(619, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Epizode koje se emitiraju sutra:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Osvježi prikaz";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 447);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SutraListBox);
            this.Controls.Add(this.DanasListBox);
            this.Controls.Add(this.JucerListBox);
            this.Controls.Add(this.PregledSerijaButton);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "TVCritic";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PregledSerijaButton;
        private System.Windows.Forms.ListBox JucerListBox;
        private System.Windows.Forms.ListBox DanasListBox;
        private System.Windows.Forms.ListBox SutraListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}

