﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using TVCritic.Model;
using TVCritic.Common;
using TVCritic.Controllers;

using TVCritic.Model.Repozitoriji;

namespace TVCritic.Main
{
    public partial class SezonaForm : Form, ISezonaForm
    {
        public SezonaForm(CriticController inController, int inSerijaID, int inSezonaID)
        {
            InitializeComponent();
            _criticController = inController;

            numericUpDown1.Value = _criticController.dohvatiOcjenuSezone(inSerijaID, inSezonaID);
            _serijaID = inSerijaID;
            _sezonaID = inSezonaID;
            
            RefreshEpisodes();
        }
        private CriticController _criticController = null;

        private int _serijaID = -1;

        private int _sezonaID = -1;

        private void EpizodeListBox_Click(object sender, EventArgs e)
        {
            
        }
        private void EpizodeListBox_DoubleClick(object sender, EventArgs e)
        {
            if ((sender as ListBox).SelectedItem == null) return;
            Epizoda ep = ((EpizodaListBoxItem)(sender as ListBox).SelectedItem).epizoda;

            IEpizodaForm ef = new EpizodaForm(_criticController, ep.IDSerija, ep.IDSezona, ep.RedniBroj);
            _criticController.prikaziEpizodu(ef);
        }

        public bool ShowForm()
        {
            this.Show();
            return true;
        }

        private void RefreshEpisodes()
        {
            if (_criticController == null || _serijaID == -1 || _sezonaID == -1) return;
            List<Epizoda> epizode = _criticController.dohvatiEpizode(_serijaID, _sezonaID);
            numericUpDown1.Value = _criticController.dohvatiOcjenuSezone(_serijaID, _sezonaID);
            this.Text = _criticController.dohvatiNazivSerije(_serijaID) + " - " + "S" + _sezonaID.ToString();
            EpizodeListBox.Items.Clear();
            foreach(Epizoda ep in epizode)
            {
                EpizodeListBox.Items.Add(new EpizodaListBoxItem("S" + ep.IDSezona.ToString() + "E" + ep.RedniBroj.ToString() + "\t" + ep.Naziv, ep));
            }
        }
        public void UpdateObserver()
        {
            RefreshEpisodes();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (_criticController == null || _serijaID == -1 || _sezonaID == -1) return;
            _criticController.postaviOcjenuSezone(_serijaID, _sezonaID, (int)numericUpDown1.Value);
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            if (_criticController == null || _serijaID == -1 || _sezonaID == -1) return;
            IAddEpisode addE = new AddEpisodeForm();
            _criticController.dodajEpizodu(addE, _serijaID, _sezonaID);
        }

        private void btnUkloni_Click(object sender, EventArgs e)
        {
            if (EpizodeListBox.SelectedItem == null) return;
            Epizoda ep = ((EpizodaListBoxItem)EpizodeListBox.SelectedItem).epizoda;
            _criticController.ukloniEpizodu(ep.IDSerija, ep.IDSezona, ep.RedniBroj);
        }

        

    }
}
