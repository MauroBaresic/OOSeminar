﻿namespace TVCritic.Main
{
    partial class KritikaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PoslodavciListBox = new System.Windows.Forms.ListBox();
            this.PoslodavacUkloniButton = new System.Windows.Forms.Button();
            this.PoslodavacDodajButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.KritikaTextBox = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OcjenaLabel = new System.Windows.Forms.Label();
            this.NazivKritikeLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PoslodavciListBox);
            this.groupBox1.Controls.Add(this.PoslodavacUkloniButton);
            this.groupBox1.Controls.Add(this.PoslodavacDodajButton);
            this.groupBox1.Location = new System.Drawing.Point(180, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(299, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Poslodavci";
            // 
            // PoslodavciListBox
            // 
            this.PoslodavciListBox.FormattingEnabled = true;
            this.PoslodavciListBox.Location = new System.Drawing.Point(89, 20);
            this.PoslodavciListBox.Name = "PoslodavciListBox";
            this.PoslodavciListBox.Size = new System.Drawing.Size(204, 69);
            this.PoslodavciListBox.TabIndex = 2;
            // 
            // PoslodavacUkloniButton
            // 
            this.PoslodavacUkloniButton.Location = new System.Drawing.Point(7, 50);
            this.PoslodavacUkloniButton.Name = "PoslodavacUkloniButton";
            this.PoslodavacUkloniButton.Size = new System.Drawing.Size(75, 23);
            this.PoslodavacUkloniButton.TabIndex = 1;
            this.PoslodavacUkloniButton.Text = "Ukloni";
            this.PoslodavacUkloniButton.UseVisualStyleBackColor = true;
            this.PoslodavacUkloniButton.Click += new System.EventHandler(this.PoslodavacUkloniButton_Click);
            // 
            // PoslodavacDodajButton
            // 
            this.PoslodavacDodajButton.Location = new System.Drawing.Point(7, 20);
            this.PoslodavacDodajButton.Name = "PoslodavacDodajButton";
            this.PoslodavacDodajButton.Size = new System.Drawing.Size(75, 23);
            this.PoslodavacDodajButton.TabIndex = 0;
            this.PoslodavacDodajButton.Text = "Dodaj";
            this.PoslodavacDodajButton.UseVisualStyleBackColor = true;
            this.PoslodavacDodajButton.Click += new System.EventHandler(this.PoslodavacDodajButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.SaveButton.Location = new System.Drawing.Point(289, 483);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 1;
            this.SaveButton.Text = "Spremi";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelButton.Location = new System.Drawing.Point(383, 483);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 2;
            this.CancelButton.Text = "Odustani";
            this.CancelButton.UseVisualStyleBackColor = true;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.AddExtension = false;
            // 
            // KritikaTextBox
            // 
            this.KritikaTextBox.Location = new System.Drawing.Point(13, 161);
            this.KritikaTextBox.Name = "KritikaTextBox";
            this.KritikaTextBox.Size = new System.Drawing.Size(466, 291);
            this.KritikaTextBox.TabIndex = 3;
            this.KritikaTextBox.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ocjena serije:";
            // 
            // OcjenaLabel
            // 
            this.OcjenaLabel.AutoSize = true;
            this.OcjenaLabel.Location = new System.Drawing.Point(89, 75);
            this.OcjenaLabel.Name = "OcjenaLabel";
            this.OcjenaLabel.Size = new System.Drawing.Size(13, 13);
            this.OcjenaLabel.TabIndex = 5;
            this.OcjenaLabel.Text = "0";
            // 
            // NazivKritikeLabel
            // 
            this.NazivKritikeLabel.AutoSize = true;
            this.NazivKritikeLabel.Location = new System.Drawing.Point(16, 19);
            this.NazivKritikeLabel.Name = "NazivKritikeLabel";
            this.NazivKritikeLabel.Size = new System.Drawing.Size(35, 13);
            this.NazivKritikeLabel.TabIndex = 8;
            this.NazivKritikeLabel.Text = "label4";
            // 
            // KritikaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 518);
            this.Controls.Add(this.NazivKritikeLabel);
            this.Controls.Add(this.OcjenaLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.KritikaTextBox);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.groupBox1);
            this.Name = "KritikaForm";
            this.Text = "Nova kritika";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox PoslodavciListBox;
        private System.Windows.Forms.Button PoslodavacUkloniButton;
        private System.Windows.Forms.Button PoslodavacDodajButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.RichTextBox KritikaTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label OcjenaLabel;
        private System.Windows.Forms.Label NazivKritikeLabel;
    }
}