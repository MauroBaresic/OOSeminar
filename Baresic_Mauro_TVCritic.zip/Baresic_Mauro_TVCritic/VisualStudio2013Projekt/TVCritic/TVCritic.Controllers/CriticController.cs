﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TVCritic.Model;
using TVCritic.Model.Repozitoriji;
using TVCritic.Common;

namespace TVCritic.Controllers
{
    public class CriticController : Subject
    {
        public void prikaziSerije(IPregledSerijaForm psf)
        {
            this.addObserver(psf);
            psf.ShowForm();
        }

        public void dodajSeriju(IAddSeries addS)
        {
            if(addS.ShowForm() == true)
            {
                int serijaID =SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID();
                string naziv = addS.Naziv;
                int godina = Convert.ToInt32(addS.Godina);
                Serija serija = new Serija(serijaID, godina,naziv );
                SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija);
                this.notify();
            }
        }
        public void dodajSezonu(IAddSeason addS, int serijaID)
        {
            if (addS.ShowForm() == true)
            {
                if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
                {
                    string naziv = addS.Naziv;
                    int godina = Convert.ToInt32(addS.Godina);
                    int redniBroj = Convert.ToInt32(addS.RedniBroj);
                    Sezona sezona = new Sezona(serijaID, godina, redniBroj, naziv);
                    Serija ser = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                    if (ser.sezonaPostoji(sezona.RedniBroj)) return;
                    ser.dodajSezonu(sezona);
                    this.notify();
                }
            }
        }

        public void prikaziSezone(ISerijaForm sf)
        {
            this.addObserver(sf);
            sf.ShowForm();
        }

        public void prikaziEpizode(ISezonaForm sf)
        {
            this.addObserver(sf);
            sf.ShowForm();
        }

        public void dodajEpizodu(IAddEpisode addE, int serijaID, int sezonaID)
        {
            if (addE.ShowForm() == true)
            {
                if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
                {
                    string naziv = addE.Naziv;
                    int redniBroj = Convert.ToInt32(addE.RedniBroj);
                    DateTime datum = addE.Datum;
                    Epizoda ep = new Epizoda(serijaID, sezonaID, redniBroj, naziv, datum);
                    Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                    foreach (Sezona sez in s.dohvatiSezone())
                    {
                        if (sez.RedniBroj == sezonaID)
                        {
                            if (sez.epizodaPostoji(ep.RedniBroj)) return;
                            sez.dodajEpizodu(ep);
                            this.notify();
                            break;
                        }
                    }
                }
            }
        }

        public void prikaziEpizodu(IEpizodaForm ef)
        {
            ef.ShowForm();
        }

        public void prikaziKritiku(IKritikaForm kf)
        {
            if(kf.ShowForm() == true)
            {
                Kritika kritika = new Kritika(kf.Naziv, kf.Poslodavci, kf.Tekst);
                if (kf.Poslodavci != null)
                {
                    KritikaPrintService.ispis(kf.PathKritika, kritika);
                    KritikaRepozitorij.dohvatiInstancu().dodajKritiku(kritika);
                }
            }

        }

        

        public Poslodavac dodajPoslodavca(IAddPoslodavac addP)
        {
            if(addP.ShowForm() == true)
            {
                return new Poslodavac(addP.Naziv, addP.FormatKritike);
            }
            return null;
        }

        public List<Epizoda> dohvatiEpizodeOdJucer()
        {
            DateTime datum = DateTime.Now;
            List<Epizoda> le = new List<Epizoda>();
            foreach(Serija ser in SerijaRepozitorij.dohvatiInstancu().dohvatiSerije())
            {
                foreach(Sezona sez in ser.dohvatiSezone())
                {
                    foreach(Epizoda ep in sez.dohvatiEpizode())
                    {
                        if (ep.Datum.Date == datum.Date.AddDays(-1))
                            le.Add(ep);
                    }
                }
            }

            return le;
        }

        public List<Epizoda> dohvatiEpizodeOdDanas()
        {
            DateTime datum = DateTime.Now;
            List<Epizoda> le = new List<Epizoda>();
            foreach (Serija ser in SerijaRepozitorij.dohvatiInstancu().dohvatiSerije())
            {
                foreach (Sezona sez in ser.dohvatiSezone())
                {
                    foreach (Epizoda ep in sez.dohvatiEpizode())
                    {
                        if (ep.Datum.Date == datum.Date)
                            le.Add(ep);
                    }
                }
            }

            return le;
        }

        public List<Epizoda> dohvatiEpizodeOdSutra()
        {
            DateTime datum = DateTime.Now;
            List<Epizoda> le = new List<Epizoda>();
            foreach (Serija ser in SerijaRepozitorij.dohvatiInstancu().dohvatiSerije())
            {
                foreach (Sezona sez in ser.dohvatiSezone())
                {
                    foreach (Epizoda ep in sez.dohvatiEpizode())
                    {
                        if (ep.Datum.Date == datum.Date.AddDays(1))
                            le.Add(ep);
                    }
                }
            }

            return le;
        }

        public string dohvatiKratkiNazivEpizode(int serijaID, int sezonaID, int redniBroj)
        {
            string naziv = "";
            if(SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach(Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        foreach(Epizoda ep in sez.dohvatiEpizode())
                        {
                            if (ep.RedniBroj == redniBroj)
                            {
                                naziv = s.Naziv + "\tS" + sez.RedniBroj.ToString() + "E" + ep.RedniBroj.ToString();
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            return naziv;
        }

        public List<Serija> dohvatiSerije()
        {
            List<Serija> serije = SerijaRepozitorij.dohvatiInstancu().dohvatiSerije();

            return serije;
        }

        public string dohvatiNazivSerije(int serijaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                return s.Naziv + " (" + s.Godina.ToString() + ")";
            }
            return "";
        }

        public List<Sezona> dohvatiSezone(int serijaID)
        {
            List<Sezona> sezone = new List<Sezona>();
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                return SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID).dohvatiSezone();
            }
            return sezone;
        }

        public List<Epizoda> dohvatiEpizode(int serijaID, int sezonaID)
        {
            List<Epizoda> epizode = new List<Epizoda>();
            if(SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach(Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        return sez.dohvatiEpizode();
                    }
                }
            }
            return epizode;
        }

        public void postaviOcjenuSerije(int serijaID, int ocjena)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                s.Ocjena = ocjena;
            }
        }

        public int dohvatiOcjenuSerije(int serijaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                return s.Ocjena;
            }
            return 0;
        }

        public string izracunajOcjenu(int serijaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                double x = s.izracunajOcjenu();
                return x.ToString();
            }
            return "0";
        }

        public void postaviKritikaEnabledSerije(int serijaID, bool enabled)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                s.KritikaEnabled = enabled;
            }
        }

        public bool dohvatiKritikaEnabledSerije(int serijaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                return s.KritikaEnabled;
            }
            return false;
        }

        public void postaviOcjenuSezone(int serijaID, int sezonaID, int ocjena)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach(Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        sez.Ocjena = ocjena;
                        break;
                    }
                }
            }
        }

        public int dohvatiOcjenuSezone(int serijaID, int sezonaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach (Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        return sez.Ocjena;
                    }
                }
            }
            return 0;
        }

        public void dodajGenre()
        {

        }

        public void ukloniSeriju(int serijaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                SerijaRepozitorij.dohvatiInstancu().ukloniSeriju(serijaID);
                this.notify();
            }
        }

        public void ukloniSezonu(int serijaID, int sezonaID)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                if (s.sezonaPostoji(sezonaID))
                {
                    s.ukloniSezonu(sezonaID);
                    this.notify();
                }
            }
        }

        public void ukloniEpizodu(int serijaID, int sezonaID, int redniBroj)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach (Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        if (sez.epizodaPostoji(redniBroj))
                        {
                            sez.ukloniEpizodu(redniBroj);
                            this.notify();
                            return;
                        }
                    }
                }
            }
        }

        public void postaviOcjenuEpizode(int serijaID, int sezonaID,int redniBroj, int ocjena)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach (Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        foreach (Epizoda ep in sez.dohvatiEpizode())
                        {
                            if (ep.RedniBroj == redniBroj)
                            {
                                ep.Ocjena = ocjena;
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        }

        public int dohvatiOcjenuEpizode(int serijaID, int sezonaID, int redniBroj)
        {
            if (SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serijaID))
            {
                Serija s = SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serijaID);
                foreach (Sezona sez in s.dohvatiSezone())
                {
                    if (sez.RedniBroj == sezonaID)
                    {
                        foreach(Epizoda ep in sez.dohvatiEpizode())
                        {
                            if(ep.RedniBroj == redniBroj)
                            {
                                return ep.Ocjena;
                            }
                        }
                        break;
                    }
                }
            }
            return 0;
        }

        public void NapuniRepozitorij()
        {
            Epizoda ep1 = new Epizoda(1, 1, 1, "Winter Is Coming", DateTime.Now.AddDays(-1));
            Epizoda ep2 = new Epizoda(1, 1, 2, "The Kingsroad", DateTime.Now.AddDays(-1));
            Epizoda ep3 = new Epizoda(1, 1, 3, "Lord Snow", DateTime.Now.AddDays(-1));
            Epizoda ep4 = new Epizoda(1, 1, 4, "Cripples, Bastards and Broken Things", DateTime.Now);
            Epizoda ep5 = new Epizoda(1, 1, 5, "The Wolf and the Lion", DateTime.Now);
            Epizoda ep6 = new Epizoda(1, 1, 6, "A Golden Crown", DateTime.Now);
            Epizoda ep7 = new Epizoda(1, 1, 7, "You Win or you Die", DateTime.Now);
            Epizoda ep8 = new Epizoda(1, 1, 8, "The Pointy End", DateTime.Now);
            Epizoda ep9 = new Epizoda(1, 1, 9, "Baelor", DateTime.Now);
            Epizoda ep10 = new Epizoda(1, 1, 10, "Fire and Blood", DateTime.Now);

            Sezona s1 = new Sezona(1, 2011, 1, "Season 1");
            s1.dodajEpizodu(ep1);
            s1.dodajEpizodu(ep2);
            s1.dodajEpizodu(ep3);
            s1.dodajEpizodu(ep4);
            s1.dodajEpizodu(ep5);
            s1.dodajEpizodu(ep6);
            s1.dodajEpizodu(ep7);
            s1.dodajEpizodu(ep8);
            s1.dodajEpizodu(ep9);
            s1.dodajEpizodu(ep10);


            Epizoda ep11 = new Epizoda(1, 2, 1, "ep21", DateTime.Now.AddDays(1));
            Epizoda ep12 = new Epizoda(1, 2, 2, "ep22", DateTime.Now.AddDays(1));
            Epizoda ep13 = new Epizoda(1, 2, 3, "ep23", DateTime.Now.AddDays(1));

            Sezona s2 = new Sezona(1, 2012, 2, "Season 2");
            s2.dodajEpizodu(ep11);
            s2.dodajEpizodu(ep12);
            s2.dodajEpizodu(ep13);

            Sezona s3 = new Sezona(1, 2013, 3, "Season 3");
            Sezona s4 = new Sezona(1, 2014, 4, "Season 4");
            Sezona s5 = new Sezona(1, 2015, 5, "Season 5");
            Sezona s6 = new Sezona(1, 2016, 6, "Season 6");

            Serija serija1 = new Serija(1, 2011, "Game of Thrones");
            serija1.dodajSezonu(s1);
            serija1.dodajSezonu(s2);
            serija1.dodajSezonu(s3);
            serija1.dodajSezonu(s4);
            serija1.dodajSezonu(s5);
            serija1.dodajSezonu(s6);

            Serija serija2 = new Serija(2, 2010, "Sherlock");
            Serija serija3 = new Serija(3, 2013, "Hannibal");
            Serija serija4 = new Serija(4, 2014, "True Detective");
            Serija serija5 = new Serija(5, 2014, "Fargo");
            Serija serija6 = new Serija(6, 2013, "Da Vinci's Demons");
            Serija serija7 = new Serija(7, 2005, "How I Met Your Mother");
            Serija serija8 = new Serija(8, 2001, "24");
            Serija serija9 = new Serija(9, 2008, "The Mentalist");
            Serija serija10 = new Serija(10, 2013, "Vikings");
            Serija serija11 = new Serija(11, 2014, "Outlander");

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija1);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija2);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija3);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija4);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija5);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija6);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija7);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija8);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija9);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija10);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija11);
        }
    }
}
