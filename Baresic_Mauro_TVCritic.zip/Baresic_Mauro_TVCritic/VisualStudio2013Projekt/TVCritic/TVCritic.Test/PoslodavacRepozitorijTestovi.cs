﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TVCritic.Model;
using TVCritic.Model.Repozitoriji;

namespace TVCritic.Test
{
    [TestClass]
    public class PoslodavacRepozitorijTestovi
    {
        [TestMethod]
        public void TestAddOnePoslodavac()
        {
            Poslodavac poslodavac = new Poslodavac("IMDB", ".txt");
            int broj = PoslodavacRepozitorij.dohvatiInstancu().dohvatiPoslodavce().Count;

            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac);

            Assert.AreEqual(broj + 1, PoslodavacRepozitorij.dohvatiInstancu().dohvatiPoslodavce().Count);
        }

        [TestMethod]
        public void TestAddOnePoslodavacCheckIfExists()
        {
            Poslodavac poslodavac = new Poslodavac("IMDB2", ".txt");

            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac);

            Assert.AreEqual(true, PoslodavacRepozitorij.dohvatiInstancu().poslodavacPostoji(poslodavac.Naziv));
        }

        [TestMethod]
        [ExpectedException(typeof(PoslodavacAlreadyExists))]
        public void TestAddPoslodavacAlreadyExists()
        {
            string naziv = "poslodavac3";
            Poslodavac poslodavac = new Poslodavac(naziv, ".txt");
            Poslodavac poslodavac2 = new Poslodavac(naziv, ".txt");

            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac);
            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac2);
        }

        [TestMethod]
        public void TestAddRemoveOnePoslodavac()
        {
            Poslodavac poslodavac = new Poslodavac("poslodavac4", ".txt");

            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac);
            int broj = PoslodavacRepozitorij.dohvatiInstancu().dohvatiPoslodavce().Count;
            PoslodavacRepozitorij.dohvatiInstancu().ukloniPoslodavca(poslodavac.Naziv);

            Assert.AreEqual(broj - 1, PoslodavacRepozitorij.dohvatiInstancu().dohvatiPoslodavce().Count);
        }

        [TestMethod]
        public void TestAddRemoveOnePoslodavacCheckIfExists()
        {
            Poslodavac poslodavac = new Poslodavac("poslodavac5", ".txt");

            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac);
            PoslodavacRepozitorij.dohvatiInstancu().ukloniPoslodavca(poslodavac.Naziv);

            Assert.AreEqual(false, PoslodavacRepozitorij.dohvatiInstancu().poslodavacPostoji(poslodavac.Naziv));
        }

        [TestMethod]
        [ExpectedException(typeof(PoslodavacDoesNotExist))]
        public void TestRemovePoslodavacDoesNotExist()
        {
            Poslodavac poslodavac = new Poslodavac("poslodavac6", ".txt");

            PoslodavacRepozitorij.dohvatiInstancu().dodajPoslodavca(poslodavac);
            PoslodavacRepozitorij.dohvatiInstancu().ukloniPoslodavca(poslodavac.Naziv + "7");
        }

    }
}
