﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TVCritic.Model;

namespace TVCritic.Test
{
    [TestClass]
    public class SezonaTestovi
    {
        [TestMethod]
        public void TestAddOneEpisode()
        {
            Epizoda epizoda = new Epizoda(1, 1, 1, "ep1", DateTime.Now);
            Sezona sezona = new Sezona(1, 2015, 1, "sezona1");
            int brojEpizoda = sezona.BrojEpizoda;

            sezona.dodajEpizodu(epizoda);

            Assert.AreEqual(brojEpizoda + 1, sezona.BrojEpizoda);
        }

        [TestMethod]
        public void TestAddOneEpisodeCheckIfExists()
        {
            int epID = 1;
            Epizoda epizoda = new Epizoda(2, 2, epID, "ep1", DateTime.Now);
            Sezona sezona = new Sezona(2, 2015, 2, "sezona2");

            sezona.dodajEpizodu(epizoda);

            Assert.AreEqual(true, sezona.epizodaPostoji(epID));
        }

        [TestMethod]
        public void TestAddRemoveOneEpisodeCheckIfExists()
        {
            int epID = 1;
            Epizoda epizoda = new Epizoda(2, 2, epID, "ep1", DateTime.Now);
            Sezona sezona = new Sezona(2, 2015, 2, "sezona2");

            sezona.dodajEpizodu(epizoda);
            sezona.ukloniEpizodu(epizoda.RedniBroj);

            Assert.AreEqual(false, sezona.epizodaPostoji(epID));
        }

        [TestMethod]
        [ExpectedException(typeof(EpisodeAlreadyExists))]
        public void TestAddEpisodeWithSameID()
        {
            int epID = 1;
            Epizoda epizoda = new Epizoda(2, 2, epID, "ep1", DateTime.Now);
            Epizoda epizoda2 = new Epizoda(2, 2, epID, "ep1", DateTime.Now);
            Sezona sezona = new Sezona(2, 2015, 2, "sezona2");

            sezona.dodajEpizodu(epizoda);
            sezona.dodajEpizodu(epizoda2);
        }

        [TestMethod]
        public void TestAddRemoveOneEpisode()
        {
            Epizoda epizoda = new Epizoda(1, 1, 1, "ep1", DateTime.Now);
            Sezona sezona = new Sezona(1, 2015, 1, "sezona1");

            sezona.dodajEpizodu(epizoda);
            int brojEpizoda = sezona.BrojEpizoda;
            sezona.ukloniEpizodu(epizoda.RedniBroj);

            Assert.AreEqual(brojEpizoda - 1, sezona.BrojEpizoda);
        }

        [TestMethod]
        [ExpectedException(typeof(EpisodeDoesNotExist))]
        public void TestRemoveEpisodeDoesNotExist()
        {
            int epID = 1;
            Epizoda epizoda = new Epizoda(2, 2, epID, "ep1", DateTime.Now);
            Sezona sezona = new Sezona(2, 2015, 2, "sezona2");

            sezona.dodajEpizodu(epizoda);
            sezona.ukloniEpizodu(epID + 1);
        }

        [TestMethod]
        public void TestComputeSeasonRatingSingle()
        {
            Sezona sezona = new Sezona(2, 2015, 2, "sezona2");
            sezona.Ocjena = 5;
            Epizoda epizoda1 = new Epizoda(2, 2, 1, "ep1", DateTime.Now);
            epizoda1.Ocjena = 7;
            Epizoda epizoda2 = new Epizoda(2, 2, 2, "ep2", DateTime.Now);
            epizoda2.Ocjena = 9;

            sezona.dodajEpizodu(epizoda1);
            sezona.dodajEpizodu(epizoda2);

            Assert.AreEqual(5, sezona.izracunajOcjenu(TipOcjene.Single));
        }

        [TestMethod]
        public void TestComputeSeasonRatingAVG()
        {
            Sezona sezona = new Sezona(2, 2015, 2, "sezona2");
            sezona.Ocjena = 5;
            Epizoda epizoda1 = new Epizoda(2, 2, 1, "ep1", DateTime.Now);
            epizoda1.Ocjena = 7;
            Epizoda epizoda2 = new Epizoda(2, 2, 2, "ep2", DateTime.Now);
            epizoda2.Ocjena = 9;

            sezona.dodajEpizodu(epizoda1);
            sezona.dodajEpizodu(epizoda2);

            Assert.AreEqual(8.0, sezona.izracunajOcjenu(TipOcjene.AVG));
        }
    }
}
