﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TVCritic.Model;
using TVCritic.Model.Repozitoriji;

namespace TVCritic.Test
{
    [TestClass]
    public class SerijaRepozitorijTestovi
    {
        [TestMethod]
        public void TestAddOneSeries()
        {
            Serija serija = new Serija(SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID(), 2015, "Serija1");
            int broj = SerijaRepozitorij.dohvatiInstancu().BrojSerija;

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija);

            Assert.AreEqual(broj + 1, SerijaRepozitorij.dohvatiInstancu().BrojSerija);
        }

        [TestMethod]
        public void TestAddOneSeriesCheckIDExists()
        {
            Serija serija = new Serija(SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID(), 2015, "Serija2");

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija);

            Assert.AreEqual(true, SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serija.ID));
        }        

        [TestMethod]
        [ExpectedException(typeof(SeriesAlreadyExists))]
        public void TestSeriesWithSameID()
        {
            int ID = SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID();
            Serija serija3 = new Serija(ID, 2015, "Serija3");
            Serija serija4 = new Serija(ID, 2015, "Serija4");

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija3);
            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija4);
        }

        [TestMethod]
        public void TestAddSeriesGetByID()
        {
            Serija serija = new Serija(SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID(), 2015, "Serija5");

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija);

            Assert.AreEqual(serija, SerijaRepozitorij.dohvatiInstancu().dohvatiSerijuPoID(serija.ID));
        }

        [TestMethod]
        public void TestAddRemoveOneSeries()
        {
            Serija serija = new Serija(SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID(), 2015, "Serija6");

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija);
            int broj = SerijaRepozitorij.dohvatiInstancu().BrojSerija;
            SerijaRepozitorij.dohvatiInstancu().ukloniSeriju(serija.ID);

            Assert.AreEqual(broj - 1, SerijaRepozitorij.dohvatiInstancu().BrojSerija);
        }

        [TestMethod]
        public void TestAddRemoveOneSeriesCheckIfExists()
        {
            Serija serija = new Serija(SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID(), 2015, "Serija7");

            SerijaRepozitorij.dohvatiInstancu().dodajSeriju(serija);
            SerijaRepozitorij.dohvatiInstancu().ukloniSeriju(serija.ID);

            Assert.AreEqual(false, SerijaRepozitorij.dohvatiInstancu().serijaPostoji(serija.ID));
        }

        [TestMethod]
        [ExpectedException(typeof(SeriesDoesNotExist))]
        public void TestRemoveSeriesDoesNotExist()
        {
            int ID = SerijaRepozitorij.dohvatiInstancu().dohvatiJedinstveniID();
            Serija serija = new Serija(ID, 2015, "Serija8");

            SerijaRepozitorij.dohvatiInstancu().ukloniSeriju(serija.ID);
        }

    }
}
