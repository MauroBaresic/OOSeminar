﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TVCritic.Model;

namespace TVCritic.Test
{
    [TestClass]
    public class SerijaTestovi
    {
        [TestMethod]
        public void TestAddOneGenreToSeries()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            Genre genre = new Genre("drama");
            int broj = serija.dohvatiGenres().Count;

            serija.dodajGenre(genre);

            Assert.AreEqual(broj + 1, serija.dohvatiGenres().Count);
        }

        [TestMethod]
        [ExpectedException(typeof(GenreAlreadyExists))]
        public void TestAddGenreToSeriesAlreadyExists()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            string naziv = "drama";
            Genre genre = new Genre(naziv);
            Genre genre2 = new Genre(naziv);

            serija.dodajGenre(genre);
            serija.dodajGenre(genre2);
        }

        [TestMethod]
        public void TestAddOneSeason()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            Sezona sezona = new Sezona(1, 2015, 1, "sezona1");
            int brojSezona = serija.dohvatiSezone().Count;

            serija.dodajSezonu(sezona);

            Assert.AreEqual(brojSezona + 1, serija.dohvatiSezone().Count);
        }

        [TestMethod]
        public void TestAddOneSeasonCheckIfExists()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            int idSez = 1;
            Sezona sezona = new Sezona(1, 2015, idSez, "sezona1");

            serija.dodajSezonu(sezona);

            Assert.AreEqual(true, serija.sezonaPostoji(idSez));
        }

        [TestMethod]
        public void TestAddRemoveOneSeasonCheckIfExists()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            int idSez = 1;
            Sezona sezona = new Sezona(1, 2015, idSez, "sezona1");

            serija.dodajSezonu(sezona);
            serija.ukloniSezonu(idSez);

            Assert.AreEqual(false, serija.sezonaPostoji(idSez));
        }

        [TestMethod]
        [ExpectedException(typeof(SeasonAlreadyExists))]
        public void TestAddSeasonAlreadyExists()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            int idSez = 1;
            Sezona sezona = new Sezona(1, 2015, idSez, "sezona1");
            Sezona sezona2 = new Sezona(1, 2015, idSez, "sezona1");

            serija.dodajSezonu(sezona);
            serija.dodajSezonu(sezona2);
        }

        [TestMethod]
        public void TestAddRemoveOneSeason()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            Sezona sezona = new Sezona(1, 2015, 1, "sezona1");
            
            serija.dodajSezonu(sezona);
            int brojSezona = serija.dohvatiSezone().Count;
            serija.ukloniSezonu(sezona.RedniBroj);

            Assert.AreEqual(brojSezona - 1, serija.dohvatiSezone().Count);
        }


        [TestMethod]
        [ExpectedException(typeof(SeasonDoesNotExist))]
        public void TestRemoveSeasonDoesNotExist()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            int idSez = 1;
            Sezona sezona = new Sezona(1, 2015, idSez, "sezona1");

            serija.dodajSezonu(sezona);
            serija.ukloniSezonu(idSez + 1);
        }

        [TestMethod]
        public void TestComputeSeriesRatingsSingle()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            serija.Ocjena = 10;
            Sezona sezona1 = new Sezona(1, 2015, 1, "sezona1");
            Epizoda ep11 = new Epizoda(1, 1, 1, "ep11", DateTime.Now);
            ep11.Ocjena = 4;
            Epizoda ep12 = new Epizoda(1, 1, 2, "ep12", DateTime.Now);
            ep12.Ocjena = 6;
            Sezona sezona2 = new Sezona(1, 2016, 2, "sezona2");
            Epizoda ep21 = new Epizoda(1, 2, 1, "ep21", DateTime.Now);
            ep21.Ocjena = 7;
            Epizoda ep22 = new Epizoda(1, 2, 2, "ep22", DateTime.Now);
            ep22.Ocjena = 9;

            sezona2.dodajEpizodu(ep21);
            sezona2.dodajEpizodu(ep22);
            sezona1.dodajEpizodu(ep11);
            sezona1.dodajEpizodu(ep12);
            serija.dodajSezonu(sezona1);
            serija.dodajSezonu(sezona2);
            serija.KritikaEnabled = false;

            Assert.AreEqual(10, serija.izracunajOcjenu());
        }

        [TestMethod]
        public void TestComputeSeriesRatingsAVG()
        {
            Serija serija = new Serija(1, 2015, "serija1");
            serija.Ocjena = 10;
            Sezona sezona1 = new Sezona(1, 2015, 1, "sezona1");
            Epizoda ep11 = new Epizoda(1, 1, 1, "ep11", DateTime.Now);
            ep11.Ocjena = 4;
            Epizoda ep12 = new Epizoda(1, 1, 2, "ep12", DateTime.Now);
            ep12.Ocjena = 6;
            Sezona sezona2 = new Sezona(1, 2016, 2, "sezona2");
            Epizoda ep21 = new Epizoda(1, 2, 1, "ep21", DateTime.Now);
            ep21.Ocjena = 7;
            Epizoda ep22 = new Epizoda(1, 2, 2, "ep22", DateTime.Now);
            ep22.Ocjena = 9;

            sezona2.dodajEpizodu(ep21);
            sezona2.dodajEpizodu(ep22);
            sezona1.dodajEpizodu(ep11);
            sezona1.dodajEpizodu(ep12);
            serija.dodajSezonu(sezona1);
            serija.dodajSezonu(sezona2);

            Assert.AreEqual(6.5, serija.izracunajOcjenu());
        }

    }
}
