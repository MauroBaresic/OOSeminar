﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TVCritic.Model;
using TVCritic.Model.Repozitoriji;

namespace TVCritic.Test
{
    [TestClass]
    public class GenreRepozitorijTestovi
    {
        [TestMethod]
        public void TestAddOneGenre()
        {
            Genre genre = new Genre("drama");
            int broj = GenreRepozitorij.dohvatiInstancu().brojGenres;

            GenreRepozitorij.dohvatiInstancu().dodajGenre(genre);

            Assert.AreEqual(broj + 1, GenreRepozitorij.dohvatiInstancu().brojGenres);
        }

        [TestMethod]
        public void TestAddOneGenreCheckIfExists()
        {
            string naziv = "komedija";
            Genre genre = new Genre(naziv);

            GenreRepozitorij.dohvatiInstancu().dodajGenre(genre);

            Assert.AreEqual(true, GenreRepozitorij.dohvatiInstancu().genrePostoji(naziv));
        }

        [TestMethod]
        [ExpectedException(typeof(GenreAlreadyExists))]
        public void TestAddGenreWithSameName()
        {
            string naziv = "horor";
            Genre genre = new Genre(naziv);
            Genre genre2 = new Genre(naziv);

            GenreRepozitorij.dohvatiInstancu().dodajGenre(genre);
            GenreRepozitorij.dohvatiInstancu().dodajGenre(genre2);
        }

        [TestMethod]
        public void TestAddRemoveOneGenre()
        {
            Genre genre = new Genre("avantura");

            GenreRepozitorij.dohvatiInstancu().dodajGenre(genre);
            int broj = GenreRepozitorij.dohvatiInstancu().brojGenres;
            GenreRepozitorij.dohvatiInstancu().ukloniGenre(genre.Naziv);

            Assert.AreEqual(broj - 1, GenreRepozitorij.dohvatiInstancu().brojGenres);
        }

        [TestMethod]
        public void TestAddRemoveOneGenreCheckIfExists()
        {
            string naziv = "pustolovna";
            Genre genre = new Genre(naziv);

            GenreRepozitorij.dohvatiInstancu().dodajGenre(genre);
            GenreRepozitorij.dohvatiInstancu().ukloniGenre(genre.Naziv);

            Assert.AreEqual(false, GenreRepozitorij.dohvatiInstancu().genrePostoji(naziv));
        }

        [TestMethod]
        [ExpectedException(typeof(GenreDoesNotExist))]
        public void TestRemoveGenreDoesNotExists()
        {
            string naziv = "nepostojeći žanr";
            Genre genre = new Genre(naziv);

            GenreRepozitorij.dohvatiInstancu().ukloniGenre(genre.Naziv);
        }

    }
}
