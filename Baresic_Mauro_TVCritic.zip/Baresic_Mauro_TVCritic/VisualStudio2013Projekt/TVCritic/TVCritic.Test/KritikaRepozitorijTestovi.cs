﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using TVCritic.Model;
using TVCritic.Model.Repozitoriji;

namespace TVCritic.Test
{
    [TestClass]
    public class KritikaRepozitorijTestovi
    {
        [TestMethod]
        public void TestAddOneKritika()
        {
            Kritika kritika = new Kritika("kritika1", null, "Text.");
            int broj = KritikaRepozitorij.dohvatiInstancu().dohvatiKritike().Count;

            KritikaRepozitorij.dohvatiInstancu().dodajKritiku(kritika);

            Assert.AreEqual(broj + 1, KritikaRepozitorij.dohvatiInstancu().dohvatiKritike().Count);
        }

        [TestMethod]
        public void TestAddOneKritikaCheckIfExists()
        {
            Kritika kritika = new Kritika("kritika2", null, "Text.");

            KritikaRepozitorij.dohvatiInstancu().dodajKritiku(kritika);

            Assert.AreEqual(true, KritikaRepozitorij.dohvatiInstancu().kritikaPostoji(kritika.Naziv));
        }

        [TestMethod]
        public void TestAddRemoveOneKritika()
        {
            Kritika kritika = new Kritika("kritika3", null, "Text.");

            KritikaRepozitorij.dohvatiInstancu().dodajKritiku(kritika);
            int broj = KritikaRepozitorij.dohvatiInstancu().dohvatiKritike().Count;
            KritikaRepozitorij.dohvatiInstancu().ukloniKritiku(kritika.Naziv);

            Assert.AreEqual(broj - 1, KritikaRepozitorij.dohvatiInstancu().dohvatiKritike().Count);
        }

        [TestMethod]
        public void TestAddRemoveOneKritikaCheckIfExists()
        {
            Kritika kritika = new Kritika("kritika4", null, "Text.");

            KritikaRepozitorij.dohvatiInstancu().dodajKritiku(kritika);
            KritikaRepozitorij.dohvatiInstancu().ukloniKritiku(kritika.Naziv);

            Assert.AreEqual(false, KritikaRepozitorij.dohvatiInstancu().kritikaPostoji(kritika.Naziv));
        }

        [TestMethod]
        [ExpectedException(typeof(KritikaDoesNotExist))]
        public void TestRemoveKritikaDoesNotExist()
        {
            Kritika kritika = new Kritika("kritika5", null, "Text.");

            KritikaRepozitorij.dohvatiInstancu().dodajKritiku(kritika);
            KritikaRepozitorij.dohvatiInstancu().ukloniKritiku(kritika.Naziv + "6");
        }
    }
}
