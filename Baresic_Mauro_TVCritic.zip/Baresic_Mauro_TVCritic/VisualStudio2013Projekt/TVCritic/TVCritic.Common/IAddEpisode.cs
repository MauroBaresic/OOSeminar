﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Common
{
    public interface IAddEpisode
    {
        bool ShowForm();

        string Naziv { get; }

        string RedniBroj { get; }

        DateTime Datum { get; }
    }
}
