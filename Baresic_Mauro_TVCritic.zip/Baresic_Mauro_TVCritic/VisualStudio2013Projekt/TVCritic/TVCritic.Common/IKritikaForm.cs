﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TVCritic.Model;

namespace TVCritic.Common
{
    public interface IKritikaForm
    {
        bool ShowForm();
        string Naziv { get; }
        string Tekst { get; }
        string PathKritika { get; }

        List<Poslodavac> Poslodavci { get; }
    }
}
