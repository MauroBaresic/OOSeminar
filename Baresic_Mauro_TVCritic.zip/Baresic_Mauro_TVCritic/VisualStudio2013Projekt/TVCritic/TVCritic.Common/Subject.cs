﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TVCritic.Common
{
    public class Subject
    {
        List<Observer> _observers = new List<Observer>();

        public void addObserver(Observer inObserver)
        {
            _observers.Add(inObserver);
        }

        public void notify()
        {
            foreach(Observer observer in _observers)
            {
                observer.UpdateObserver();
            }
        }
    }
}
